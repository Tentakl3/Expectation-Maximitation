import gensim
from gensim import corpora
import nltk

#Topic mining in two articles

f = open('article_1_e960401_lemmatized.txt', encoding = 'utf-8') 
text1 = f.read()
f.close()

f = open('article_2_e960401_lemmatized.txt', encoding = 'utf-8') 
text2 = f.read()
f.close()

text1 = nltk.word_tokenize(text1)
text2 = nltk.word_tokenize(text2)

from nltk.corpus import stopwords
stopwords = stopwords.words('spanish')
text1 = [word for word in text1 if word not in stopwords]
text2 = [word for word in text2 if word not in stopwords]

texts = [text1, text2]

'''Creating the term dictionary of our courpus, where every unique term is assigned an index.'''

dictionary = corpora.Dictionary(texts)

'''Converting list of documents (corpus) into Document Term Matrix using dictionary prepared above.'''
doc_term_matrix = [dictionary.doc2bow(t) for t in texts]

'''Creating the object for LDA model using gensim library'''
Lda = gensim.models.ldamodel.LdaModel

'''Running and Trainign LDA model on the document term matrix.'''
ldamodel = Lda(doc_term_matrix, num_topics=2, id2word = dictionary, passes=50)

print(ldamodel.print_topics(num_topics=2, num_words=7))